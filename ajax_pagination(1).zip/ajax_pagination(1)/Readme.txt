Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: https://makitweb.com/edit-delete-datatables-record-with-ajax-and-php/

Instructions - 
1. Import users.sql table in your MySQL database.
2. Update config.php file.

